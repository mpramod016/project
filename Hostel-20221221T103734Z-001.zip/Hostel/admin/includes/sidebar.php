<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">

				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>


				</li>
					<li><a href="#"><i class="fa fa-desktop"></i> Rooms</a>
					<ul>
						<li><a href="create-room.php">Add a Room</a></li>
						<li><a href="manage-rooms.php">Manage Rooms</a></li>

					</ul>
				</li>
	<li><a href="cater.php">Catering</a></li>
	<li><a href="reqs.php">Waiting Requests</a></li>
				<li><a href="registration.php"><i class="fa fa-user"></i>Paying Guest Registration</a></li>
				<li><a href="manage-students.php"><i class="fa fa-users"></i>Manage Paying Guest</a></li>
				<li><a href="access-log.php"><i class="fa fa-file"></i>User Access logs</a></li>


		</nav>
