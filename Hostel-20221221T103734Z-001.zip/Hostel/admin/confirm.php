<?php include 'includes/config.php';
session_start(); ?>
<?php
if(isset($_GET['id'])){
  $id=$_GET['id'];
  $ret="select * from req where id=$id";
  $stmt= $mysqli->prepare($ret) ;
  //$stmt->bind_param('i',$aid);
  $stmt->execute() ;//ok
  $res=$stmt->get_result();
  while($row=$res->fetch_object())
      {
    //  $id=$row->id'];
      $roomno=$row->roomno;
        $seater=$row->seater;
          $feespm=$row->feespm;
            $foodstatus=$row->foodstatus;
              $stayfrom=$row->stayfrom;
                $duration=$row->duration;
                  $course=$row->course;
                    $regno=$row->regno;
                      $firstName=$row->firstName;
                        $middleName=$row->middleName;
                          $lastName=$row->lastName;
                            $gender=$row->gender;
                              $contactno=$row->contactno;
                                $emailid=$row->emailid;
                                  $egycontactno=$row->egycontactno;
                                    $guardianName=$row->guardianName;
                                      $guardianRelation=$row->guardianRelation;
                                        $guardianContactno=$row->guardianContactno;
                                          $corresAddress=$row->corresAddres;
                                            $corresCity=$row->corresCity;
                                            $corresState=$row->corresState;
                                            $corresPincode=$row->$corresPincode;
                                            $pmntAddress=$row->pmntAddress;
                                            $pmntCity=$row->pmntCity;
                                            $pmnatetState=$row->pmnatetState;
                                                $pmntPincode=$row->pmntPincode;








        $query="insert into  registration(roomno,seater,feespm,foodstatus,stayfrom,duration,course,regno,firstName,middleName,lastName,gender,contactno,emailid,egycontactno,guardianName,guardianRelation,guardianContactno,corresAddress,corresCIty,corresState,corresPincode,pmntAddress,pmntCity,pmnatetState,pmntPincode) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        $stmt = $mysqli->prepare($query);
        $rc=$stmt->bind_param('iiiisisissssisississsisssi',$roomno,$seater,$feespm,$foodstatus,$stayfrom,$duration,$course,$regno,$firstName,$middleName,$lastName,$gender,$contactno,$emailid,$egycontactno,$guardianName,$guardianRelation,$guardianContactno,$corresAddress,$corresCity,$corresState,$corresPincode,$pmntAddress,$pmntCity,$pmnatetState,$pmntPincode);
        $stmt->execute();
        $deq="delete from req where id=$id";
        $stmt = $mysqli->prepare($deq);

        $stmt->execute();
        if($stmt==1){}
        header("Location:reqs.php");
      }

} ?>
